from bicycle_control.longitudinal_pid import PIDLongitudinalController


def test_longitudinal_pid_positive_error():
    """Vehicle slower than target speed -> positive throttle."""
    controller = PIDLongitudinalController(kp=1.0, ki=0.1, kd=0.01, dt=0.1)
    u_throttle = controller.compute(target_vel=5.0, current_vel=3.0)
    assert u_throttle > 0.0
    assert u_throttle <= 1.0


def test_longitudinal_pid_negative_error():
    """Vehicle faster than target speed -> negative throttle / braking."""
    controller = PIDLongitudinalController(kp=1.0, ki=0.1, kd=0.01, dt=0.1)
    u_throttle = controller.compute(target_vel=3.0, current_vel=5.0)
    assert u_throttle < 0.0
    assert u_throttle >= -1.0


def test_longitudinal_pid_anti_windup():
    """Sustained error should not cause unbounded integral accumulation."""
    controller = PIDLongitudinalController(kp=1.0, ki=1.0, kd=0.0, dt=0.1, integral_limit=2.0)
    for _ in range(100):
        controller.compute(target_vel=10.0, current_vel=0.0)
    assert controller.integral <= 2.0
    assert controller.integral >= -2.0


def test_longitudinal_pid_no_derivative_kick_on_setpoint_change():
    """A jump in the target speed must not make the derivative term spike."""
    controller = PIDLongitudinalController(kp=0.0, ki=0.0, kd=1.0, dt=0.1)
    controller.compute(target_vel=3.0, current_vel=3.0)
    u = controller.compute(target_vel=7.0, current_vel=3.0)  # target jumps, speed unchanged
    assert abs(u) < 1e-9


def test_longitudinal_pid_rate_limit():
    """With max_rate the throttle may only change by max_rate * dt per step."""
    controller = PIDLongitudinalController(kp=10.0, ki=0.0, kd=0.0, dt=0.1, max_rate=2.0)
    u1 = controller.compute(target_vel=10.0, current_vel=0.0)
    u2 = controller.compute(target_vel=10.0, current_vel=0.0)
    assert abs(u1 - 0.2) < 1e-9
    assert abs(u2 - 0.4) < 1e-9


def test_longitudinal_pid_closed_loop_reaches_target():
    """Closed loop against the simulator's drag model converges to the target speed."""
    controller = PIDLongitudinalController(dt=0.1, max_rate=6.0)
    v = 0.0
    for _ in range(400):
        th = controller.compute(4.0, v)
        v += (4.0 * th - (0.005 * v * v + 0.05 * v)) * 0.1
    assert abs(v - 4.0) < 0.05
