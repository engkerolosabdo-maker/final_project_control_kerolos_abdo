"""
Target Velocity Profiler based on track curvature.
Calculates maximum safe cornering speeds subject to lateral acceleration limits.
"""

import math


class VelocityProfiler:
    """Generates target speed profiles based on track curvature or precomputed data."""

    def __init__(self, default_speed=4.0, max_speed=8.0, max_lat_accel=5.0, min_speed=1.0):
        self.default_speed = default_speed
        self.max_speed = max_speed
        self.max_lat_accel = max_lat_accel
        self.min_speed = min_speed

    def compute_target_speed(self, kappa, fallback_speed=None):
        """Calculates curvature-limited velocity: v_max = sqrt(a_lat_max / |kappa|)."""
        # Invalid curvature (None / NaN / inf): use the fallback speed
        if kappa is None or not math.isfinite(kappa):
            return float(fallback_speed if fallback_speed is not None else self.default_speed)

        k = abs(kappa)

        # Practically straight: nothing limits the speed except max_speed
        if k < 1e-4:
            return float(self.max_speed)

        # Lateral acceleration a = v^2 * kappa  ->  v = sqrt(a_lat_max / kappa)
        v = math.sqrt(self.max_lat_accel / k)
        return float(min(max(v, self.min_speed), self.max_speed))
