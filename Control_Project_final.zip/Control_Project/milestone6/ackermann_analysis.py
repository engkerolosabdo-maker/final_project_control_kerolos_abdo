"""Milestone 6 - four-wheel Ackermann kinematics for the Bicycle Gym car.

Shows how the single-track (bicycle) steering angle maps to the two real front wheel
angles, what the wheel speeds are in a turn, and that the 4-wheel model produces the same
body motion as the bicycle model the controllers use.

Geometry (from the project description):  L = 1.25 m, T = 1.18 m, wheel radius r = 0.5 m.
Convention: positive steering = turn left, so the LEFT wheel is the inner wheel for delta > 0.
"""
import math

L = 1.25      # wheelbase (m)
T = 1.18      # track width between wheel centres (m)
R_W = 0.5     # wheel radius (m)
MAX_DELTA = math.radians(35.0)


def ackermann_angles(delta, L=L, T=T):
    """Bicycle steering angle -> (left, right) front wheel angles, both CCW positive.

    Turning radius of the rear-axle centre is R = L / tan(delta).  Each front wheel must
    point perpendicular to the line joining it to the instantaneous centre of rotation:
        tan(delta_left)  = L / (R - T/2) = L tan(d) / (L - (T/2) tan(d))
        tan(delta_right) = L / (R + T/2) = L tan(d) / (L + (T/2) tan(d))
    """
    t = math.tan(delta)
    left = math.atan2(L * t, L - 0.5 * T * t)
    right = math.atan2(L * t, L + 0.5 * T * t)
    return left, right


def wheel_speeds(v, delta, L=L, T=T):
    """Speeds of the four wheel centres (m/s) for a body speed v at the rear-axle centre.

    Every wheel lies at a different distance from the instantaneous centre of rotation,
    so every wheel needs a different speed (this is what a differential does).
    Returns dict with rear_left, rear_right, front_left, front_right.
    """
    if abs(delta) < 1e-9:
        return {k: v for k in ('rear_left', 'rear_right', 'front_left', 'front_right')}
    omega = v * math.tan(delta) / L                 # yaw rate (rad/s), same as bicycle model
    # Positions relative to the rear-axle centre: x forward, y left; ICR at (0, R)
    R = L / math.tan(delta)
    out = {}
    for name, (px, py) in {'rear_left': (0, T / 2), 'rear_right': (0, -T / 2),
                           'front_left': (L, T / 2), 'front_right': (L, -T / 2)}.items():
        out[name] = abs(omega) * math.hypot(px, py - R)
    return out


def simulate(model, v=3.0, delta=math.radians(20.0), t_end=10.0, dt=0.001):
    """Integrate one steady turn with the bicycle model or a 4-wheel Ackermann model.

    The 4-wheel version computes the pose of the rear-axle centre from the two REAR wheel
    speeds (differential-drive style), driven by the front wheel angles.
    """
    x = y = th = 0.0
    for _ in range(int(t_end / dt)):
        if model == 'bicycle':
            x += v * math.cos(th) * dt
            y += v * math.sin(th) * dt
            th += v / L * math.tan(delta) * dt
        else:
            sp = wheel_speeds(v, delta)
            sign = 1.0 if delta >= 0 else -1.0
            v_l, v_r = sp['rear_left'], sp['rear_right']
            # inner wheel is the slower one: left for a left turn
            if sign > 0:
                vl, vr = min(v_l, v_r), max(v_l, v_r)
            else:
                vl, vr = max(v_l, v_r), min(v_l, v_r)
            vc = 0.5 * (vl + vr)
            om = (vr - vl) / T
            x += vc * math.cos(th) * dt
            y += vc * math.sin(th) * dt
            th += om * dt
    return x, y, th


if __name__ == '__main__':
    print('=== Front wheel angles for a given bicycle steering angle ===')
    print(f'{"delta":>7}{"R (m)":>9}{"left":>9}{"right":>9}{"inner-outer":>13}')
    for d_deg in (5, 10, 15, 20, 25, 30, 35):
        d = math.radians(d_deg)
        l, r = ackermann_angles(d)
        print(f'{d_deg:6d}°{L / math.tan(d):9.2f}{math.degrees(l):8.1f}°{math.degrees(r):8.1f}°'
              f'{math.degrees(l - r):12.1f}°')

    l, r = ackermann_angles(MAX_DELTA)
    print(f'\nAt the 35° limit the inner wheel needs {math.degrees(l):.1f}° '
          f'(URDF hinge limit is {math.degrees(0.610865):.1f}°).')
    print(f'Minimum turning radius, rear-axle centre: {L / math.tan(MAX_DELTA):.2f} m')
    print(f'Minimum turning radius, outer front wheel: '
          f'{math.hypot(L, L / math.tan(MAX_DELTA) + T / 2):.2f} m')

    print('\n=== Wheel speeds, v = 3 m/s, delta = 35° (left turn) ===')
    for k, s in wheel_speeds(3.0, MAX_DELTA).items():
        print(f'{k:12s}{s:6.3f} m/s   wheel rpm {s / R_W * 60 / (2 * math.pi):6.1f}')

    print('\n=== Bicycle vs 4-wheel Ackermann, 10 s steady turn (v=3, delta=20°) ===')
    b = simulate('bicycle')
    a = simulate('ackermann')
    print(f'bicycle  : x={b[0]:.3f} y={b[1]:.3f} yaw={math.degrees(b[2]):.2f}°')
    print(f'ackermann: x={a[0]:.3f} y={a[1]:.3f} yaw={math.degrees(a[2]):.2f}°')
    print(f'position difference: {math.hypot(a[0] - b[0], a[1] - b[1]) * 1000:.2f} mm')

    print('\n=== Cost of NOT using Ackermann (both wheels at the same angle 35°) ===')
    inner_err = math.degrees(l - MAX_DELTA)
    print(f'inner wheel is {inner_err:.1f}° under-steered -> tyre scrub / lateral slip '
          f'that a kinematic model ignores')
